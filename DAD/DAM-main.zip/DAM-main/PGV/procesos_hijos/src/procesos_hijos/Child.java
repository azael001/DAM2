package procesos_hijos;

import java.util.Scanner;

public class Child {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println(teclado.nextLine());
    }
}
