# DAM

Para los proyectos de AED y PGV, usa IntelliJ (asegúrate de abrir la carpeta "DAM") para que las rutas relativas en el programa funcionen.