"# ProyectosReact" 
```
npm create vite@latest
cd miapp
npm install
npm run dev
```