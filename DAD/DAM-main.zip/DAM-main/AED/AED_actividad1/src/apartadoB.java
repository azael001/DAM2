
public class apartadoB {
	public static void main(String[] args) {
		
	}
}
